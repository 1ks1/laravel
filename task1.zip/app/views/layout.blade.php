
  @section('header_h')
<a href="{{dirname($_SERVER['PHP_SELF'])}}/home">Home</a>
@show

