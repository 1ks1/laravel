<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
</head>
<body>
{{date('Y:M:d D h:m:s')}}
<h1>Home page</h1>
    php self: {{$_SERVER['PHP_SELF']}}<br />
    dirname: {{dirname($_SERVER['PHP_SELF'])}}<br />
    dirname from controller:{{$dir_name}}
    <hr />
    <a href="{{$dir_name}}/articles">articles</a> | 
    <a href="{{$dir_name}}/contact-us">contact-us</a> | 
    <a href="{{$dir_name}}/about">about</a>

</body>
</html>