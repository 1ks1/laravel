<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
<style>
body{margin:0;}
.test{
    padding:5px;
    width:100%;
    background:#ccc;
    color:#fff;
    font-weight:800;
    box-shadow:2px 2px 4px #000;
}
.test span{
    color:#f00;
}
</style>
</head>
<body>
{{date('Y:M:d D h:m:s')}}
<h1>Home page</h1>
<div class="test">
<span>test path</span><br />
    php self: {{$_SERVER['PHP_SELF']}}<br />
    dirname: {{dirname($_SERVER['PHP_SELF'])}}<br />
    dirname from controller:{{$dir_name}}<br />
    <br />
</div>
    <br /><hr />
    <a href="{{$dir_name}}/articles">articles</a> | 
    <a href="{{$dir_name}}/contact-us">contact-us</a> | 
    <a href="{{$dir_name}}/about">about</a>

</body>
</html>