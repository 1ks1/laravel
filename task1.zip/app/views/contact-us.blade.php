<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>contact-us</title>

</head>
<body>
    <h1>contact-us</h1>

    @if($error == 'message')
    <b>Error message!</b> Please enter message.
    @elseif($error == 'name')
    <b>Error name!</b> Please enter you name.
    @elseif($error == 'all')
    <b>Error!</b> Please compleate all fields.
    @endif
    <div>
        <form action="contact-us" method="POST">
        <input type="text" name="name" /><br />
        <textarea rows="10" cols="45" name="message"></textarea><br />
        <button type="submit">Send</button>
        </form>
    </div>
</body>
</html>