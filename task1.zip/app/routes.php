<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{
	//return View::make('hello');
	return Redirect::to('/home');
	return 'hello Dude!';
});

Route::get('/home', 'HomeController@showHome');
Route::get('/about', 'HomeController@showAbout');
Route::get('/articles/{id?}', 'HomeController@showArticles');
Route::get('/contact-us', 'HomeController@showContact');
Route::get('/links', 'HomeController@showLinks');


Route::post('/contact-us', function()
{
    // Get the user's first and last name.
    $name = Input::get('nameame');
    $message  = Input::get('message');
});

  

