<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{
	//return View::make('hello');
	return Redirect::to('/home');
	//return 'hello Dude!';
});

Route::get('/home', 'HomeController@showHome');
Route::get('/about', 'HomeController@showAbout');
Route::get('articles/{id?}', 'HomeController@showArticles');
Route::get('contact-us/{error?}', 'HomeController@showContact');
Route::get('thank-you/{name?}', 'HomeController@showThanks');
Route::post('contact-us', function()
{
    $name = Input::get('name');
	$message  = Input::get('message');
	$error = 0;
	if ((strlen($name) <= 1) && (isset($name)))
	$error += 1;
	if ((strlen($message) <= 1) && (isset($message)))
	$error += 2;
	if (0 == $error)
	{
		return Redirect::action('HomeController@showThanks',$name);	
	} 
	else 
	{
		if (1 == $error)
		return Redirect::action('HomeController@showContact', ['error'=>'name']);
		if (2 == $error)
		return Redirect::action('HomeController@showContact', ['error'=>'message']);
		if (3 == $error)
		return Redirect::action('HomeController@showContact', ['error'=>'all']);
	}
	
});

  

