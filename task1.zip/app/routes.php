<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{
	//return View::make('hello');
	return Redirect::to('/home');
	//return 'hello Dude!';
});

Route::get('/home', 'HomeController@showHome');
Route::get('/about', 'HomeController@showAbout');
Route::get('/articles/{id?}', 'HomeController@showArticles');
Route::get('contact-us/{error?}', 'HomeController@showContact');
Route::get('/links', 'HomeController@showLinks');
Route::get('thank-you/{id?}', 'HomeController@showThanks');


Route::post('/contact-us', function()
{
    $name = Input::get('name');
	$message  = Input::get('message');
	if (strlen($name) > 0  && strlen($message) > 0)
	{
		//return Redirect::action('HomeController@showThanks', array('name' => 'Vasia'));
		return Redirect::to('thank-you/'.$name);
	} 
	else 
	{
		return Redirect::to('contact-us');
	}
	
});

  

