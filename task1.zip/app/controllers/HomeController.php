<?php

class HomeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	
	public function showWelcome()
	{
		return View::make('hello');
	}

	public function showHome()
	{
		$dir_name = dirname($_SERVER['PHP_SELF']);
		return View::make('home',['dir_name'=> $dir_name]);
	}

	public function showArticles($id='')
	{
		$arr['dirr'] = dirname($_SERVER['PHP_SELF']);
		$arr['id'] = $id;
		return View::make('articles',$arr);
	}

	public function showAbout()
	{
		return View::make('about');
	}

	public function showContact($error='')
	{
		return View::make('contact-us',['error'=>$error]);
	}

	public function showThanks($name='')
	{	
		return View::make('thank-you',['name'=>$name]);
	}

	

}
