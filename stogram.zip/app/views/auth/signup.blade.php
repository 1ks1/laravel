@extends('layout')

@section('content')
<li>Sign up</li>
<form action="" method="POST">
<input type="text" name="name" placeholder="Name" /><br />
<input type="text" name="email" placeholder="Email" /><br />
<input type="password" name="password" placeholder="Password" /><br />
<input type="password" name="password_confirmation" placeholder="Password" /><br />
<input type="submit" />
</form>
@stop