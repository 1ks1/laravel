@extends('layout')

@section('content')
<li>Sign IN</li>
<form action="" method="POST">
<input type="text" name="name" placeholder="Name" /><br />
<input type="text" name="email" placeholder="Email" /><br />
<input type="password" name="password" placeholder="Password" /><br />
<input type="submit" />
</form>
@stop