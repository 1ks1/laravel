<?php

class HomeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function showWelcome()
	{
		return View::make('hello');
	}

	public function showArtist($id)
	{
		$artist = Artist::find($id);
		$albums = $artist->albums;
		  return View::make('artist')->with(['id'=>$id,'albums'=>$albums]);
	}
	
	public function showAlbum($id)
	{
		$album = Album::find($id);
		$tracks = $album->track;
		//var_dump($tracks);
		return View::make('album')->with(['id'=>$id,'tracks'=>$tracks]);
	}
	
	

	public function showHome()
	{
		$artist = Artist::all();
		return View::make('home',compact('artist'));
	}

}
