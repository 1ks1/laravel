<?PHP
class Album extends Eloquent
{
    protected $table = 'Album';
    protected $primaryKey = 'AlbumId';
    public $timestemps = false;
	
	 public function track()
    {
        return $this->hasMany('Track','AlbumId','AlbumId');
    }

    //public function album()
    //{
    //    return $this->hasMany('Album','AlbumId','AlbumId');
    //}

    public function artist()
    {
        return $this->belongsTo('Artist','ArtistId','ArtistId');
    }

}