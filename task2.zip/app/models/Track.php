<?PHP
class Track extends Eloquent
{
    protected $table = 'Track';
    protected $primaryKey = 'TrackId';
    public $timestemps = false;

    public function tracks()
    {
        return $this->belongsTo('Track','TrackId','TrackId');
    }
	
	public function albums()
    {
        return $this->hasMany('Album','AlbumId','AlbumId');
    }

}