<?php

class Genre extends Eloquent 
{
    protected $table = 'Genre';
    protected $primaryKey = 'GenreId';
    public $timestemps = false;

    public function genre()
    {
        return $this->hasMany('Genre','GenreId','GenreId');
    }

}
