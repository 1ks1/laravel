<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Task2</title>
    <style>
        body{
            margin:0;
            padding:0;
            background:#eef;
        }
    </style>
</head>
<body>
<div id="header">
    @yield('footer')
    <h2>Task2</h2>
    <hr />
    </div>

    <div id="content">
    @yield('content')
    </div>
    <div id="footer">
    @yield('footer')
    Copyright
    </div>
</body>
</html>