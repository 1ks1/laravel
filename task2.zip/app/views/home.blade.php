@extends('layout')


@section('content')
•Home•<hr />
Artists:
<ul>
@foreach($artist as $a)
<li><a href={{  url("/artist/$a->ArtistId")  }}>#{{$a->ArtistId}} - {{$a->Name}}</a></li>
@endforeach
</ul>
@stop


@section('footer')

@stop