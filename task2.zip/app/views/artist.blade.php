@extends('layout')


@section('content')
<a href={{  url("/home/")  }}>•Home•</a><hr />
Albums:<br />
<h4>{{Artist::find($id)->Name}}</h4>
<ul>
@foreach($albums as $a)
<li><a href={{  url("/album/$a->AlbumId")  }}>{{$a->Title}}</a></li>
@endforeach
</ul>
@stop


@section('footer')

@stop