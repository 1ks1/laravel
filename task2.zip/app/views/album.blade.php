@extends('layout')


@section('content')
<a href={{  url("/home/")  }}>•Home•</a><hr />
Tracks:<br />
<ul>
@foreach($tracks as $t)
<br />
<li>{{$t}}</li>
@endforeach
</ul>
@stop


@section('footer')

@stop