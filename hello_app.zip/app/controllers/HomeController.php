<?php

class HomeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function showWelcome()
	{
		return View::make('Welcome!');
	}

	public function showH()
	{
		return View::make('h');
	}

	public function showForm()
	{
		$name = Input::old('name');
		$list = array(
			'about'=>'/about',
			'contact'=>'/contact',
			'Tos'=>'/tos'
		);
		return View::make('form',array('name'=>$name, 'urls'=> null));
	}


	public function postSubmit()
	{
		if (Input::has('name'))
		{
			$name = Input::get('name');
			return Redirect::action('HomeController@showHello')->withInput();
		}
		
		return Redirect::route('/form');
	}

	

	public function showHello()
	{
		$name = Input::old('name');
		return View::make('hello!');
	}

	public function dbTest($id)
	{
		//$user = DB::select('select * from users where id=?',[$id]);
		//$user= DB::table('users')->where('id',$id)->select('name')->get();
		//$user = DB::table('users')->insert(['name'=>'test1']);
		print_r('<br />');
		print_r(DB::table('users')->where('name','LIKE','%t%')->take(1)->get());
		print_r('<br />');


		if(DB::table('users')->where('name','test1')->count())
		{
			$user = DB::table('users')->where('name','test1')->take(1)->delete();
			return 'User exists and was delete';

		}else{
			$user = DB::table('users')->insert(['name'=>'test1']);
		}
		if ($user = true)
		{
			print_r('insert = true<br />');
		}else{
			print_r($user);
		}
		
		return View::make('db');
	}






	public function dbTesting($id)
	{
		//$tracks = Track::find($id);
		//$tracks = Track::where('Name','LIKE','%sh%')->get();
		//$tracks = Track::where('Milliseconds','<',5*60*1000)->get();
		//var_dump($tracks);

		
		$artist = Artist::find($id);
		//var_dump($artist->tracks);
		
		$albums = $artist->albums;
		foreach ($albums as $album)
		{
			echo "(".$album->artist->Name.") ".$album->Title."<br />";
			$tracks = $album->tracks;
			foreach($tracks as $track)
			{
				echo $track->album->Title.' - '.$track->Name."<br />";
			}
		}




		
		//var_dump($tracks);
		//return View::make('songlist',compact('tracks'));
		//return View::make('songs');
	}
	
}
