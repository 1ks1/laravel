<?PHP
class HelloController extends BaseController
{
    public function showHello()
    {
        #return 'Hello dude!';
        #$content[] = ('some_content','content2');
        return View::make('test',array('message'=>'MyMessage'));
    }
}