<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

// Route::get('/', function()
// {
// 	return View::make('hello');
// });

Route::get('/', function(){
	return 'WeLcOmE!';
});




Route::get('/user/{id?}', function($id)
{
	return 'user'.$id;
});
Route::get('/h', 'HomeController@showH');
Route::get('/test2', 'HomeController@showHello');
//Route::get('/form', array('as'=>'form','uses'=>'HomeController@showForm');
Route::get('/form', 'HomeController@showForm');
Route::get('/submit', 'HomeController@postSubmit');
Route::get('/db/{id?}', 'HomeController@dbTest');
Route::get('/dbtest/{id?}', 'HomeController@dbTesting');