@extends('layout')

@section('content')
<form method="POST" action="{{action('HomeController@postImage')}}" enctype="multipart/form-data">
<label>Name: <input type="text" name="name"></label>
<label>Image: <input type="file" name="image"></label>
<label>Description: <textarea name="description"></textarea></label>
<button type="submit">Upload</button>
</form>

@stop


