@extends('layout')

@section('content')
<div class="image">
<img src="{{action('HomeController@getImageFile', $image->id)}}" title="{{$image->name}}"/>
<p>{{$image->description}}</p>
</div>
@stop
