<?php

class Image extends Eloquent
{
	
}
