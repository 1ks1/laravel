<?php

return array(
	'path' => storage_path() . '/images'	
);
